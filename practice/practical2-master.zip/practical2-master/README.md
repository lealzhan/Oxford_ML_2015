# Practical 2
Machine Learning, spring 2015

## Setup
Setup will be the same as last time in practical 1. Please refer to the [practical 1 repository](https://github.com/oxford-cs-ml-2015/practical1), and run the script as instructed last time.

# See course page for practicals
<https://www.cs.ox.ac.uk/people/nando.defreitas/machinelearning/>

